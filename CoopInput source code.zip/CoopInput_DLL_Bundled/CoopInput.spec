# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['coopinput.py'],
    pathex=[],
    binaries=[('coopinput_hook.dll', '.'), ('C:/Users/Kodec/Desktop/CoopInput_DLL_Bundled/vendor/Interception/x64/interception.dll', '.')],
    datas=[('assets/CoopInput.ico', '.')],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='CoopInput',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['assets/CoopInput.ico'],
    contents_directory='.',
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='CoopInput',
)
